#!/usr/bin/python3
from http import client
from itertools import count
import json
from result_output import ResultOutput
import importlib.util
import sys
from pprint import pprint
import docker
import socket
import mysql.connector as mysql

InstanceId = ""
SecurityGroup = []

db = mysql.connect(
                    host = "localhost",
                    user = "root",
                    passwd = "Root123$"
                )



class Activity():

    
    def testcase_check_Database(self,test_object):
        testcase_description="Checking Database Created "
        expected_result="employee"
        actual = ""
        test_object.update_pre_result(testcase_description,expected_result)
        # print("Came back")
        try: 
            cursor = db.cursor()
            cursor.execute("SHOW DATABASES")
            databases = cursor.fetchall()
            # print(dir(databases))
            for database in databases:
                if database[0] == "employee":
                    actual = "employee"
                    return test_object.update_result(1,expected_result,actual,testcase_description,"nuvepro.com")
            actual = "resource not found"
            return test_object.update_result(0,expected_result,actual,testcase_description,"nuvepro.com")            

        except Exception as e:    
            print(str(e))
            test_object.update_result(-1,expected_result,"Internal Server error","Please check with Admin","")
            test_object.eval_message["testcase_check_Container"]=str(e)
    
    def testcase_check_TableName(self,test_object):
        testcase_description="Checking Table and properties"
        expected_result="employee"
        actual = ""
        point = list()
        test_object.update_pre_result(testcase_description,expected_result)
        try:
            
            cursor = db.cursor()
            cursor.execute("use employee")
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            for table in tables:
                if table[0] == "employee":
                    cursor.execute("DESC employee")
                    table_props = cursor.fetchall()
                    count = 0
                    for props in table_props:
                        if props[0] == "id":
                            print(type(props[1]))
                            if "int" in str(props[1]):
                                count += 1
                        if props[0] == "name":
                            print(type(props[1]))
                            if "varchar" in str(props[1]):
                                count += 1
                
                    if count == 2:
                        actual = "employee"
                        return test_object.update_result(1,expected_result,actual,testcase_description,"nuvepro.com")
            
            actual = "resource not found"
            return test_object.update_result(0,expected_result,actual,testcase_description,"nuvepro.com")
        except Exception as e:    
            test_object.update_result(-1,expected_result,"Internal Server error","Please check with Admin","")
            test_object.eval_message["testcase_check_Image"]=str(e)
    
    def testcase_check_TableContent(self,test_object):
        testcase_description="Checking employee Table rows "
        expected_result="More than 1 row"
        actual = ""
        point = list()
        test_object.update_pre_result(testcase_description,expected_result)
        try: 
            cursor = db.cursor()
            cursor.execute("use employee")
            cursor.execute("select count(*) from employee")
            total = cursor.fetchall()
            if total[0][0] > 1:



                return test_object.update_result(1,expected_result,actual,testcase_description,"nuvepro.com")
            
            actual = 'less than 2 rows'
            return test_object.update_result(0,expected_result,actual,testcase_description,"nuvepro.com")
            

        except Exception as e:    
            test_object.update_result(-1,expected_result,"Internal Server error","Please check with Admin","")
            test_object.eval_message["testcase_check_localHost"]=str(e)

    def testcase_check_Webnet(self,test_object):
        testcase_description="Checking webnet "
        expected_result="Checking webnet"
        actual = ""
        point = list()
        test_object.update_pre_result(testcase_description,expected_result)
        try: 
            count = 0
            client = docker.from_env()
            res = client.networks.list()
            for network in res:
                if network.name == "webnet":
                    actual = "webnet"
                    return test_object.update_result(1,expected_result,actual,testcase_description,"nuvepro.com")
                else:
                    actual += network.name+", "
            return test_object.update_result(0,expected_result,actual,testcase_description,"nuvepro.com")
            

        except Exception as e:    
            test_object.update_result(-1,expected_result,"Internal Server error","Please check with Admin","")
            test_object.eval_message["testcase_check_localHost"]=str(e)


def start_tests(args):
    # args=sys.argv[1]
    
    
    if "result_output" not in sys.modules:
        importlib.import_module("result_output")
    else:   
        importlib.reload(sys.modules["result_output"])

    
    challenge_test=Activity()
    test_object=ResultOutput(args)
    challenge_test.testcase_check_Database(test_object)
    challenge_test.testcase_check_TableName(test_object)
    challenge_test.testcase_check_TableContent(test_object)
    # challenge_test.testcase_check_Webnet(test_object)

    print(json.dumps(test_object.result_final(),indent=4))
    return test_object.result_final()

def main():
    
    args = sys.argv[1]
    start_tests(args)

if __name__== "__main__" :
    main()
