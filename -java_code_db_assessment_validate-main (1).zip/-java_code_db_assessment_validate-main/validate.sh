#!/bin/python
python3 /tmp/clv/validate.py
